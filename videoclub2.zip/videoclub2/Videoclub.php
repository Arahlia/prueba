<?php
require_once("autoload.php");
class Videoclub
{
    private array $productos = [];
    private array $clientes = [];

    public function __construct(private string $nombre)
    {
    } //con pivados lo que no se puede hacer es heredar pero si setters y getters

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }
    public function getProductos(){
        return $this->productos;
    }
    public function getClientes(){
        return $this->clientes;
    }
    public function __toString()
    {
        return "Nombre: {$this->nombre}";
    }
    public function __clone()
    {
        foreach ($this->productos as $index =>$producto){
            $this->productos[$index]=clone($producto);
        }
        foreach ($this->clientes as $index =>$cliente){
            $this->clientes[$index]=clone($cliente);
        }
    }
    private function anyadirProducto(Producto $producto): void
    {
        $this->productos[$producto->getCodigo()] = $producto;
    }
    public function anyadirJuego(string $nombre, string $codigo, string $plataforma, string $genero):void{
        $juego= new Juego($nombre, $codigo, $plataforma, $genero);
        $this->anyadirProducto($juego);
        echo "Incluido juego {$codigo}";
    }
    public function anyadirCd(string $nombre, string $codigo, string $duracion, string $genero):void{
        $cd= new Cd($nombre, $codigo, $duracion, $genero);
        $this->anyadirProducto($cd);
        echo "Incluido cd {$codigo}";
    }
    public function anyadirPelicula(string $nombre, string $codigo, string $idioma, string $duracion, string $genero):void{
        $pelicula= new Pelicula($nombre, $codigo, $idioma, $duracion, $genero);
        $this->anyadirProducto($pelicula);
        echo "Incluida pelicula {$codigo}";
    }

    public function anyadirCliente(string $nombre, string $dni)
    {
        $this->clientes[$dni] = new Cliente($nombre, $dni);
        echo "Incluido cliente {$dni}<br>";
    }

    public function alquilarClienteProducto(string $dniCliente, string $codigoProducto): string
    {
        if (!isset($this->clientes[$dniCliente])) {
            return "No existe este cliente";
        } else if (!isset($this->productos[$codigoProducto])) {
            return "No existe este producto";
        } else {
            $cliente= $this->clientes[$dniCliente];
            $cliente->alquilar($this->productos[$codigoProducto]);
            $this->productos[$codigoProducto]->setEstado('alquilado');
            return "Producto alquilado correctamente";
        }
        return "No se ha podido realizar el alquiler";
    }
}

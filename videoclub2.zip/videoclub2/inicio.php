<?php
require_once("autoload.php");
session_start();
if (!isset($_SESSION["videoclub1"])) {
    header("location:carga_de_datos.php");
    exit();//para que no se siga ejecutando el php de después a pesar de haber redireccionado
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div id="inicio">
        <h1>Videoclub 1</h1>
        <form action="TodosProductos.php" method="post">
            <input type="submit" value="Ver todos los productos">
        </form>
        <form action="TodosClientes.php" method="post">
            <input type="submit" value="Ver Clientes">
        </form>
        <form action="VerProductos.php" method="post">
            <input type="submit" value="Listar productos">
        </form>
        <form action="Fantasma.php" method="post">
            <input type="submit" value="Salir">
        </form>
    </div>
</body>

</html>
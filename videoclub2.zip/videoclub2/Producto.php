<?php
require_once("autoload.php");
abstract class Producto{ //clase abstract puede no tener metodo abstracto, pero no tiene sentido que no tenga conceptualmente hablando
    protected string $nombre;
    protected float $precio;
    protected string $codigo;
    protected string $estado='devuelto';

    public function __construct(string $nombre, float $precio, string $codigo){
       $this->nombre=$nombre; 
       $this->precio=$precio; 
       $this->codigo=$codigo; 
    }

    public function getNombre():string{
        return $this->nombre;
    }
    abstract public function getPrecio():int;
    public function getCodigo():string{
        return $this->codigo;
    }
    public function getEstado(){
        return $this->estado;
    }
    public function setNombre($nombre){
        $this->nombre=$nombre;
    }
    public function setPrecio($precio){
        $this->precio=$precio;
    }
    public function setCodigo($codigo){
        $this->codigo=$codigo;
    }
    public function setEstado($estado){
        $this->estado=$estado;
    }
    public function __tostring(){
        return "Nombre: {$this->nombre} <br>Código de producto: {$this->codigo} <br>
        Precio: {$this->precio} <br>";
    }
}
<?php
require_once("autoload.php");
class Cd extends Producto
{
   private string $duracion;
   private string $genero;
   public function __construct(string $nombre, string $codigo, string $duracion, string $genero)
   {
      parent::__construct($nombre, 1, $codigo);
      $this->duracion = $duracion;
      $this->genero = $genero;
   }
   public function getDuracion(): string
   {
      return $this->duracion;
   }
   public function getGenero(): string
   {
      return $this->genero;
   }
   public function getPrecio(): int
   {
      return 1;
   }

   public function setDuracion($duracion)
   {
      $this->duracion = $duracion;
   }
   public function setGenero($genero)
   {
      $this->genero = $genero;
   }
   public function setPrecio($precio)
   {
      $this->precio = $precio;
   }

   public function __toString()
   {
      return parent::__tostring() . "Duración: {$this->duracion} <br> Género: {$this->genero}";
   }
}

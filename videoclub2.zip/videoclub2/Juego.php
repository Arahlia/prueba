<?php
require_once("autoload.php");
class Juego extends Producto{
    private string $plataforma;
    private string $genero;
    public function __construct(string $nombre, string $codigo, string $plataforma, string $genero){
    parent::__construct($nombre, 3, $codigo);
    $this->plataforma=$plataforma;
    $this->genero=$genero;
   }

    public function getPlataforma():string{
        return $this->plataforma;
    }
    public function getGenero():string{
        return $this->genero;
    }
    public function getPrecio():int{
        return 3;
    }
    
    public function setPlataforma($plataforma){
        $this->plataforma=$plataforma;
    }
    public function setGenero($genero){
        $this->genero=$genero;
    }

    public function __toString(){
        return parent::__tostring()."Plataforma: {$this->plataforma} <br> Género: {$this->genero}";
    }
    
}
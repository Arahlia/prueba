<?php
require_once("autoload.php");
class Pelicula extends Producto
{
   private string $idioma;
   private int $duracion;
   private string $genero;
   public function __construct(string $nombre, string $codigo, string $idioma, int $duracion, string $genero)
   {
      parent::__construct($nombre, 2, $codigo);
      $this->idioma = $idioma;
      $this->duracion = $duracion;
      $this->genero = $genero;
   }
   public function getIdioma(): string
   {
      return $this->idioma;
   }
   public function getDuracion(): int
   {
      return $this->duracion;
   }
   public function getGenero(): string
   {
      return $this->genero;
   }
   public function getPrecio(): int
   {
      return 2;
   }

   public function setIdioma($idioma)
   {
      $this->idioma = $idioma;
   }
   public function setDuracion($duracion)
   {
      $this->duracion = $duracion;
   }
   public function setGenero($genero)
   {
      $this->genero = $genero;
   }
   public function setPrecio($precio)
   {
      $this->precio = $precio;
   }

   public function __toString()
   {
      return parent::__tostring() . "Duración: {$this->duracion} <br> Género: {$this->genero}";
   }
}
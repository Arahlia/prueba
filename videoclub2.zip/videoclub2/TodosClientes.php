<?php
require_once("autoload.php");
session_start();
if (!isset($_SESSION["videoclub1"])) {
    header("location:carga_de_datos.php");
    exit();
}
$videoclub1 = $_SESSION["videoclub1"];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div>
        <form action="inicio.php" method="post">
            <input type="submit" value="Volver">
        </form>
    </div>
    <div id="contenedor">
        <table>
            <thead>
                <tr>
                    <th>DNI</th>
                    <th>NOMBRE</th>
                    <th>PRODUCTOS</th>
                    <th>HISTORIAL</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($videoclub1->getClientes() as $cliente) {
                    echo "<tr><td>";
                    echo $cliente->getDni();
                    echo "</td><td>";
                    echo $cliente->getNombre();
                    echo "</td>";
                ?>
                    <td>
                        <form action="TodosClientes.php" method="post">
                            <input type="submit" value="Alquilados">
                            <input type="hidden" name="alquilados" value="<?= $cliente->getDni(); ?>">
                        </form>
                    </td>
                    <td>
                        <form action="TodosClientes.php" method="post">
                            <input type="submit" value="Historial">
                            <input type="hidden" name="historial" value="<?= $cliente->getDni(); ?>">
                        </form>
                    </td>
                <?php
                }
                ?>
            </tbody>
        </table>
        <?php
        if (isset($_REQUEST['alquilados']) && count($videoclub1->getClientes()[$_REQUEST['alquilados']]->getProductosAlquilados()) != 0) {
            echo "<h3>Productos alquilados por el cliente " . $videoclub1->getClientes()[$_REQUEST['alquilados']]->getNombre() . "</h3>";
            echo '<table>';
        ?>
            <thead>
                <tr>
                    <th>TIPO</th>
                    <th>CÓDIGO</th>
                    <th>NOMBRE</th>
                    <th>GÉNERO</th>
                    <th>PRECIO</th>
                    <th>ESTADO</th>
                </tr>
            </thead>
            <?php
            foreach ($videoclub1->getClientes()[$_REQUEST['alquilados']]->getProductosAlquilados() as $productoAlquilado) {
                echo "<tr><td>";
                echo get_class($productoAlquilado);
                echo "</td><td>";
                echo $productoAlquilado->getCodigo();
                echo "</td><td>";
                echo $productoAlquilado->getNombre();
                echo "</td><td>";
                echo $productoAlquilado->getGenero();
                echo "</td><td>";
                echo $productoAlquilado->getPrecio();
                echo "</td><td>";
                echo $productoAlquilado->getEstado();
                echo "</td>";
            }
            echo '</table>';
        } else if (isset($_REQUEST['alquilados'])) {
            echo "<h3>El cliente " . $videoclub1->getClientes()[$_REQUEST['alquilados']]->getNombre() . " no tiene ningún producto alquilado actualmente</h3>";
        }
        if (isset($_REQUEST['historial']) && count($videoclub1->getClientes()[$_REQUEST['historial']]->getHistorial()) != 0) {
            echo "<h3>Historial de productos alquilados por el cliente " . $videoclub1->getClientes()[$_REQUEST['historial']]->getNombre() . "</h3>";
            echo '<table>';
            ?>
            <thead>
                <tr>
                    <th>TIPO</th>
                    <th>CÓDIGO</th>
                    <th>NOMBRE</th>
                    <th>GÉNERO</th>
                    <th>PRECIO</th>
                    <th>ESTADO</th>
                </tr>
            </thead>
        <?php
            foreach ($videoclub1->getClientes()[$_REQUEST['historial']]->getHistorial() as $productoAlquilado) {
                echo "<tr><td>";
                echo get_class($productoAlquilado);
                echo "</td><td>";
                echo $productoAlquilado->getCodigo();
                echo "</td><td>";
                echo $productoAlquilado->getNombre();
                echo "</td><td>";
                echo $productoAlquilado->getGenero();
                echo "</td><td>";
                echo $productoAlquilado->getPrecio();
                echo "</td><td>";
                echo $productoAlquilado->getEstado();
                echo "</td>";
            }
            echo '</table>';
        } else if (isset($_REQUEST['historial'])) {
            echo "<h3>El cliente " . $videoclub1->getClientes()[$_REQUEST['historial']]->getNombre() . " no ha alquilado ningún producto</h3>";
        }
        ?>
    </div>
</body>

</html>
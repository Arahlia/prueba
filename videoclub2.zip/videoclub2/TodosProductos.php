<?php
require_once("autoload.php");
session_start();

 if (!isset($_SESSION["videoclub1"])) {
    header("location:carga_de_datos.php");
    exit();
}
$videoclub1 = $_SESSION["videoclub1"];
if(isset($_REQUEST['codigAlq'], $_REQUEST['dniAlq'])){
    $codigAlq=$_REQUEST['codigAlq'];
    $dniAlq=$_REQUEST['dniAlq'];
    
    $videoclub1->alquilarClienteProducto($dniAlq, $codigAlq);
}
if(isset($_REQUEST['codigAlq']) && $_REQUEST['estado']=='alquilado'){
    $codigAlq=$_REQUEST['codigAlq'];
    foreach($videoclub1->getClientes() as $cliente){
        foreach($cliente->getProductosAlquilados() as $productoAlquilado){
            if($productoAlquilado->getCodigo()==$codigAlq){
                $cliente->devolver($productoAlquilado);
                $productoAlquilado->setEstado('devuelto');
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
        #contenedor{
            display: flex;
        }
    </style>
</head>

<body>
    <div>
        <form action="inicio.php" method="post">
            <input type="submit" value="Volver">
        </form>
    </div>
    <div id="contenedor">
    <div>
        <h2>Películas</h2>
        <table>
            <thead>
                <tr>
                    <th>CÓDIGO</th>
                    <th>NOMBRE</th>
                    <th>IDIOMA</th>
                    <th>DURACIÓN</th>
                    <th>GÉNERO</th>
                    <th>PRECIO</th>
                    <th>ESTADO</th>
                    <th>ACCIÓN</th>
                </tr>
            </thead>


            <?php
            foreach ($videoclub1->getProductos() as $producto) {
                if ($producto instanceof Pelicula) {
                    echo "<tr><td>";
                    echo $producto->getCodigo();
                    echo "</td><td>";
                    echo $producto->getNombre();
                    echo "</td><td>";
                    echo $producto->getIdioma();
                    echo "</td><td>";
                    echo $producto->getDuracion();
                    echo "</td><td>";
                    echo $producto->getGenero();
                    echo "</td><td>";
                    echo $producto->getPrecio();
                    echo "</td><td>";
                    echo $producto->getEstado();
            ?>
                    </td>
                    <td>
                        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                            <input type="submit" value="<?= ($producto->getEstado() == 'devuelto') ? 'Alquilar' : 'Devolver'; ?>">
                            <input type="hidden" name="codigAlq" value="<?=$producto->getCodigo();?>">
                            <input type="hidden" name="estado" value="<?=$producto->getEstado()?>">
                        </form>
                    </td>
            <?php
                }
            }
            ?>
        </table>
        <h2>Juegos</h2>
        <table>
            <thead>
                <tr>
                    <th>CÓDIGO</th>
                    <th>NOMBRE</th>
                    <th>PLATAFORMA</th>
                    <th>GÉNERO</th>
                    <th>PRECIO</th>
                    <th>ESTADO</th>
                    <th>ACCIÓN</th>
                </tr>
            </thead>


            <?php
            foreach ($videoclub1->getProductos() as $producto) {
                if ($producto instanceof Juego) {
                    echo "<tr><td>";
                    echo $producto->getCodigo();
                    echo "</td><td>";
                    echo $producto->getNombre();
                    echo "</td><td>";
                    echo $producto->getPlataforma();
                    echo "</td><td>";
                    echo $producto->getGenero();
                    echo "</td><td>";
                    echo $producto->getPrecio();
                    echo "</td><td>";
                    echo $producto->getEstado();
            ?>
                    </td>
                    <td>
                        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                            <input type="submit" value="<?= ($producto->getEstado() == 'devuelto') ? 'Alquilar' : 'Devolver'; ?>">
                            <input type="hidden" name="codigAlq" value="<?=$producto->getCodigo();?>">
                            <input type="hidden" name="estado" value="<?=$producto->getEstado()?>">
                        </form>
                    </td>
            <?php
                }
            }
            ?>
        </table>
        <h2>CDs</h2>
        <table>
            <thead>
                <tr>
                    <th>CÓDIGO</th>
                    <th>NOMBRE</th>
                    <th>DURACIÓN</th>
                    <th>GÉNERO</th>
                    <th>PRECIO</th>
                    <th>ESTADO</th>
                    <th>ACCIÓN</th>
                </tr>
            </thead>


            <?php
            foreach ($videoclub1->getProductos() as $producto) {
                if ($producto instanceof Cd) {
                    echo "<tr><td>";
                    echo $producto->getCodigo();
                    echo "</td><td>";
                    echo $producto->getNombre();
                    echo "</td><td>";
                    echo $producto->getDuracion();
                    echo "</td><td>";
                    echo $producto->getGenero();
                    echo "</td><td>";
                    echo $producto->getPrecio();
                    echo "</td><td>";
                    echo $producto->getEstado();
            ?>
                    </td>
                    <td>
                        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                            <input type="submit" value="<?= ($producto->getEstado() == 'devuelto') ? 'Alquilar' : 'Devolver'; ?>">
                            <input type="hidden" name="codigAlq" value="<?=$producto->getCodigo();?>">
                            <input type="hidden" name="estado" value="<?=$producto->getEstado()?>">
                        </form>
                    </td>
            <?php
                }
            }
            ?>
        </table>
    </div>
    <?php
        if(isset($_REQUEST['codigAlq']) && $_REQUEST['estado']=='devuelto'){
    ?>
        <div id="opcion">
            <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                <span>Dni del cliente:</span>
                <select name="dniAlq" id="dniAlq">
                    <option value="18048811K">Maria</option>
                    <option value="94335706X">Ana</option>
                    <option value="72120232Y">Juan</option>
                    <option value="59067487Z">David</option>
                    <option value="13629767J">Daniel</option>
                    <option value="40116985V">Natalia</option>
                    <option value="54219787R">Luis</option>
                    <option value="06508706M">Sandra</option>
                    <option value="84161940H">Laura</option>
                    <option value="16541457H">Imelda</option>
                </select>
                <input type="hidden" name="codigAlq" value="<?=$_REQUEST['codigAlq']?>">
                <input type="hidden" name="estado" value="<?=$_REQUEST['estado']?>">
                <input type="submit" value="Alquilar">
            </form>
        </div>
    <?php
        }
    ?>
    </div>
</body>

</html>
<?php
require_once("autoload.php");//primero siempre el autoload, todos los require one de las clases, para que tenga la plantilla y sepa como hacerlo
session_start();
//session_destroy();
$videoclub1= new Videoclub('Club prueba');
$videoclub1->anyadirCliente('Maria', '18048811K');
$videoclub1->anyadirCliente('Ana', '94335706X');
$videoclub1->anyadirCliente('Juan', '72120232Y');
$videoclub1->anyadirCliente('David', '59067487Z');
$videoclub1->anyadirCliente('Daniel', '13629767J');
$videoclub1->anyadirCliente('Natalia', '40116985V');
$videoclub1->anyadirCliente('Luis', '54219787R');
$videoclub1->anyadirCliente('Sandra', '06508706M');
$videoclub1->anyadirCliente('Laura', '84161940H');
$videoclub1->anyadirCliente('Imelda', '16541457H');
$videoclub1->anyadirPelicula('Los juegos del hambre', '1p', 'esp', 120, 'acción');
$videoclub1->anyadirPelicula('El chico y la garza', '2p', 'jpn', 100, 'fantasia');
$videoclub1->anyadirPelicula('Five nights at Freddys', '3p', 'eng', 120, 'terror');
$videoclub1->anyadirPelicula('The Marvels', '4p', 'esp', 110, 'acción');
$videoclub1->anyadirPelicula('Wish', '5p', 'eng', 90, 'animación');
$videoclub1->anyadirCd('Mayéutica', '1cd', 43, 'rock');
$videoclub1->anyadirCd('Evolve', '2cd', 50, 'rock');
$videoclub1->anyadirCd('Carmen', '3cd', 90, 'ópera');
$videoclub1->anyadirCd('Death of a bachelor', '4cd', 60, 'pop rock');
$videoclub1->anyadirCd('AM', '5cd', 80, 'rock');
$videoclub1->anyadirJuego("God of War", '1j', "PS4", 'acción');
$videoclub1->anyadirJuego("The Last of Us Part II",'2j', "PS4", 'terror y acción');
$videoclub1->anyadirJuego('Spiderman 2', '3j', 'PS5', 'acción');
$videoclub1->anyadirJuego('Baldurs gate III', '4j', 'PC', 'fantasia');
$videoclub1->anyadirJuego('The Witcher III', '5j', 'PC', 'acción y fantasia');
$_SESSION['videoclub1']=$videoclub1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="inicio.php" method="post">
        <input type="submit" value="Inciar aplicación">
    </form>
</body>
</html>
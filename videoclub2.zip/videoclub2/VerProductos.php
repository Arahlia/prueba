<?php
require_once("autoload.php");
session_start();

if (!isset($_SESSION["videoclub1"])) {
    header("location:carga_de_datos.php");
    exit();
}
$videoclub1 = $_SESSION["videoclub1"];
if (isset($_REQUEST['codigAlq'], $_REQUEST['dniAlq'])) {
    $codigAlq = $_REQUEST['codigAlq'];
    $dniAlq = $_REQUEST['dniAlq'];

    $videoclub1->alquilarClienteProducto($dniAlq, $codigAlq);
}
if (isset($_REQUEST['codigAlq']) && $_REQUEST['estado'] == 'alquilado') {
    $codigAlq = $_REQUEST['codigAlq'];
    foreach ($videoclub1->getClientes() as $cliente) {
        foreach ($cliente->getProductosAlquilados() as $productoAlquilado) {
            if ($productoAlquilado->getCodigo() == $codigAlq) {
                $cliente->devolver($productoAlquilado);
                $productoAlquilado->setEstado('devuelto');
            }
        }
    }
}
if (isset($_REQUEST['verEstado'])) {
    $productosPel=[];
    $productosJue=[];
    $productosCd=[];
    foreach ($videoclub1->getProductos() as $producto) {
        if (($producto instanceof Pelicula) && $producto->getEstado() == $_REQUEST['verEstado']) {
            $productosPel[]=$producto;
        }
    }
    foreach ($videoclub1->getProductos() as $producto) {
        if (($producto instanceof Juego) && $producto->getEstado() == $_REQUEST['verEstado']) {
            $productosJue[]=$producto;
        }
    }
    foreach ($videoclub1->getProductos() as $producto) {
        if (($producto instanceof Cd) && $producto->getEstado() == $_REQUEST['verEstado']) {
            $productosCd[]=$producto;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div>
        <form action="inicio.php" method="post">
            <input type="submit" value="Volver">
        </form>
    </div>
    <div>
        <form action="VerProductos.php" method="post">
            <select name="verEstado" id="verEstado">
                <option value="devuelto">Devueltos</option>
                <option value="alquilado">Pendientes de devolución</option>
            </select>
            <input type="submit" value="Ver">
        </form>
    </div>
    <?php
    if (isset($_REQUEST['verEstado'])) {
        if(count($productosPel)>0){
    ?>
        <div id="contenedor">
            <div>
                <h2>Películas</h2>
                <table>
                    <thead>
                        <tr>
                            <th>CÓDIGO</th>
                            <th>NOMBRE</th>
                            <th>IDIOMA</th>
                            <th>DURACIÓN</th>
                            <th>GÉNERO</th>
                            <th>PRECIO</th>
                            <th>ESTADO</th>
                        </tr>
                    </thead>

                    <?php
                    foreach ($productosPel as $producto) {
                        //if (($producto instanceof Pelicula) && $producto->getEstado() == $_REQUEST['verEstado']) {
                            echo "<tr><td>";
                            echo $producto->getCodigo();
                            echo "</td><td>";
                            echo $producto->getNombre();
                            echo "</td><td>";
                            echo $producto->getIdioma();
                            echo "</td><td>";
                            echo $producto->getDuracion();
                            echo "</td><td>";
                            echo $producto->getGenero();
                            echo "</td><td>";
                            echo $producto->getPrecio();
                            echo "</td><td>";
                            echo $producto->getEstado();
                            echo "</td>";
                        //}
                    }
                    echo "</table>";
        }
        if(count($productosJue)>0){
                    ?>
                <h2>Juegos</h2>
                <table>
                    <thead>
                        <tr>
                            <th>CÓDIGO</th>
                            <th>NOMBRE</th>
                            <th>PLATAFORMA</th>
                            <th>GÉNERO</th>
                            <th>PRECIO</th>
                            <th>ESTADO</th>
                        </tr>
                    </thead>


                    <?php
                    foreach ($productosJue as $producto) {
                        //if (($producto instanceof Juego) && $producto->getEstado() == $_REQUEST['verEstado']) {
                            echo "<tr><td>";
                            echo $producto->getCodigo();
                            echo "</td><td>";
                            echo $producto->getNombre();
                            echo "</td><td>";
                            echo $producto->getPlataforma();
                            echo "</td><td>";
                            echo $producto->getGenero();
                            echo "</td><td>";
                            echo $producto->getPrecio();
                            echo "</td><td>";
                            echo $producto->getEstado();
                        //}
                    }
                    echo "</table>";
        }
        if(count($productosCd)>0){
                ?>
                <h2>CDs</h2>
                <table>
                    <thead>
                        <tr>
                            <th>CÓDIGO</th>
                            <th>NOMBRE</th>
                            <th>DURACIÓN</th>
                            <th>GÉNERO</th>
                            <th>PRECIO</th>
                            <th>ESTADO</th>
                        </tr>
                    </thead>


                    <?php
                    foreach ($productosCd as $producto) {
                        //if (($producto instanceof Cd) && $producto->getEstado() == $_REQUEST['verEstado']) {
                            echo "<tr><td>";
                            echo $producto->getCodigo();
                            echo "</td><td>";
                            echo $producto->getNombre();
                            echo "</td><td>";
                            echo $producto->getDuracion();
                            echo "</td><td>";
                            echo $producto->getGenero();
                            echo "</td><td>";
                            echo $producto->getPrecio();
                            echo "</td><td>";
                            echo $producto->getEstado();
                            echo "</td>";
                        //}
                    }
                echo "</table>";
            }
                ?>
            </div>
        </div>
    <?php
    }
    ?>
</body>

</html>
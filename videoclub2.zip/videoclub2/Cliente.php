<?php
require_once("autoload.php");
class Cliente{
    private array $productosAlquilados=[];
    private array $historial=[];
    public function __construct(private string $nombre, private string $dni){}

    public function getNombre():string{
        return $this->nombre;
    }
    public function getDni():string{
        return $this->dni;
    }
    public function getProductosAlquilados(){
        return $this->productosAlquilados;
    }
    public function getHistorial(){
        return $this->historial;
    }
    public function setNombre($nombre){
        $this->nombre=$nombre;
    }
    public function setDni($dni){
        $this->dni=$dni;
    }
    public function __toString()
    {
        return "Nombre: {$this->nombre} <br> DNI: {$this->dni}";
    }
    public function __clone()
    {
        foreach ($this->productosAlquilados as $index =>$producto){
            $this->productosAlquilados[$index]=clone($producto);
        }
    }

    public function alquilar(Producto $producto){
        $this->productosAlquilados[$producto->getCodigo()]=$producto;
        $this->historial[$producto->getCodigo()]=$producto;
    }

    public function devolver(Producto $producto):bool{
        if(isset($this->productosAlquilados[$producto->getCodigo()])){
            unset($this->productosAlquilados[$producto->getCodigo()]);
            //echo 'Producto devuelto correctamente';
            //cuando se borra una posición del array se utiliza el unset
            //este no recoloca las posiciones del array, con lo que habrá huecos
            //por eso, para recorrerlo siempre utilizar foreach
            return true;
        }
        echo "Producto no alquilado por este cliente";
        return false;
    }

}